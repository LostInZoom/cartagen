# CartAGen4Py
Python open library for map generalisation, a port of the [CartAGen library](https://github.com/IGNF/CartAGen).

This library is available on [PyPI](https://pypi.org/project/cartagen4py/): 
`pip install cartagen4py`