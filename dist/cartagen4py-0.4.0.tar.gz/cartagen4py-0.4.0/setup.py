import sys
from setuptools import setup

if sys.version_info[:2] < (3, 8):
    error = ('cartagen4py requires Python 3.8 or later (%d.%d detected).' % sys.version_info[:2])
    sys.stderr.write(error + "\n")
    sys.exit(1)

LONG_DESCRIPTION_SRC = 'README.rst'

def read(file):
    with open(os.path.abspath(file), 'r', encoding='utf-8') as f:
        return f.read()

setup()