from cartagen4py.algorithms.points.quadtree import *
from cartagen4py.algorithms.points.reduction import *