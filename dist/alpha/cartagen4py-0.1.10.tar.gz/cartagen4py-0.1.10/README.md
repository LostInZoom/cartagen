# CartAGen4Py
Python open library for map generalisation, a port of the [CartAGen library](https://github.com/IGNF/CartAGen).

This library is available on [PyPI](https://pypi.org/project/cartagen4py/): 
`pip install cartagen4py`

A QGIS plugin is provided as well, just copy/paste the cartagen4qgis folder to the QGIS plugins location and install it inside QGIS.