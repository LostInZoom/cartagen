# CartAGen4Py
Python open library for map generalisation, a port of the [CartAGen library](https://github.com/IGNF/CartAGen).
