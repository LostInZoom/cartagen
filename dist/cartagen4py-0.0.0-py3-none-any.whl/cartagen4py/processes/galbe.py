import shapely
import geopandas as gpd

def run_galbe():
    """
    Apply GALBE to the provided network.
    """