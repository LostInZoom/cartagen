from cartagen4py.algorithms.points.point_set_quadtree import *
from cartagen4py.algorithms.points.point_set_reduction import *