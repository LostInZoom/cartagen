from cartagen4py.algorithms.lines.bends import *
from cartagen4py.algorithms.lines.breaks import *