from cartagen.algorithms.buildings.squaring import *
from cartagen.algorithms.buildings.displacement import *
from cartagen.algorithms.buildings.amalgamation import *
from cartagen.algorithms.buildings.regularization import *
from cartagen.algorithms.buildings.simplification import *