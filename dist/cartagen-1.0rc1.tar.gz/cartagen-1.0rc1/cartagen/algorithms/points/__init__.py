from cartagen.algorithms.points.quadtree import *
from cartagen.algorithms.points.reduction import *