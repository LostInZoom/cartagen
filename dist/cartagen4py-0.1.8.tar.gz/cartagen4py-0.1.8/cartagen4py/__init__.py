import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from cartagen4py import algorithms
from cartagen4py import data_enrichment